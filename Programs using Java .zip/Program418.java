// Customised Database Management System

class node
{
    public int Rno;
    public String Name;
    public String City;
    public int Marks;

    public node next;
}

class DBMS
{
    public node first;
}

class Program418
{
    public static void main(String Arg[])
    {


    }
}